# Currículos

Esta pasta deve conter os seguintes arquivos PDF:

- `Gustavo_Cruz_CV_EN.pdf` - Currículo em inglês
- `Gustavo_Cruz_CV_PT.pdf` - Currículo em português

Substitua este arquivo README pelos PDFs reais do currículo de Gustavo Cruz.